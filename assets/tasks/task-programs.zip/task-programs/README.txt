Skill2Real task code

Each program corresponds to one gallery recording and uses the current shared robot API. The current Proposer decision is passed as stage_inputs; execution_state is episode-local public state returned for the next stage. Motion epochs bind contact reviews and geometry to their observations. Read fresh wrist images after contact changes; select placement pixels on the image bound to the current stereo depth. Original source files are preserved separately.
